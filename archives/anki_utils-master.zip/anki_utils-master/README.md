anki_utils
==========

Short scripts that enhance Anki flashcards: export your Anki flashcards to .txt (or type up a word list, use a frequency list or whatever) and then use these handy tools in order to 
* add sample sentences and translations
* download matching sound files for each word
* order or shuffle the cards
* ... more to come

These scripts were initially created by Judith Meyer (yutian.mei@gmail.com) and are released into the Public Domain.
