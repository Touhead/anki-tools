# ImiImport
This C# tool parses the .imixch file format used by Imiwa? (really just a json file) and generates a .tsv file suitable for import into Anki and other flashcard applications.
## Usage

```
ImiImport.exe favorites.imixch > favorites.tsv
```
